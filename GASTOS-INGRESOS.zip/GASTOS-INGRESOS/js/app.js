let account = [
    {
        "id":1,
        "name":"Paga enero",
        "quantity":100
    },
    {
        "id":2,
        "name":"Compra pantalón",
        "quantity":40
    },
    {
        "id":3,
        "name":"Juego FIFA 2023",
        "quantity":40
    }
];

const inputName = document.querySelector('#name');
const inputQuantity = document.querySelector('#quantity');
const btnIncome = document.querySelector('#btn-income');
const btnExpense = document.querySelector('#btn-expense');
const conceptsList = document.querySelector('#concepts-list');

function renderAccount(){
    conceptsList.innerHTML="";
    let total=0;
    account.forEach(e => {
        total+=e.quantity;
        conceptsList.innerHTML +=
           ` <tr>
                <td>${e.name}</td>
                <td class="quantity">${e.quantity}€</td>
            </tr> `
    });
    conceptsList.innerHTML +=
        `   <tr>
                <td>Total:</td>
                <td class="quantity">${total}€</td>
            </tr>`
        ;
}

function addIcome() {
    const concept={
        "id":account.length+1,
        "name":inputName.value,  
        "quantity":parseFloat(inputQuantity.value),
    }
    account.push(concept);
    renderAccount();
}

function init() {
    renderAccount()
    btnIncome.addEventListener("click", addIcome)
}
init();